import './App.css';
import {BrowserRouter, Routes, Route} from 'react-router-dom'
import Home from './Components/Home';
import Add from './Components/Add';
import Edit from './Components/Edit';
import Delete from './Components/Delete';

function App() {
  return (
    <div>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home/>}>Home</Route>
          <Route path="/Add" element={<Add/>}>Add</Route>
          <Route path="/Edit/:id" element={<Edit/>}>Edit</Route>
          <Route path="/Delete/:id" element={<Delete/>}>Delete</Route>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
