
import React, { Component } from 'react'
import  axios from 'axios'

export class Add extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         name:'',
         mobile:'',
         email:''
      }
    }
    changeHandler = (e) => {
        this.setState(
            {[e.target.name]:e.target.value} //name here is the attribute
        )
    }
    submitHandler = (e) => {
        e.preventDefault();
        axios.post('http://localhost:4100/posts',this.state)
        .then(res=>{
            console.log(res);
            if(res.status >= 200){
                alert('User record added successfully')
                window.location = './'
            }
        })
    }
  render() {
    const {name,mobile,email} = this.state;
    return (
      <div>
       <div className='container mt-5'>
        <form onSubmit={this.submitHandler}>
            <div className='alert alert-success'>Add User</div>
            <div className='row mt-5'>
                <div className='col'>
                    <input type='text' id='name' name='name' className='form-control' placeholder='Enter Name' onChange={this.changeHandler} defaultValue={name}></input>
                </div>
                <div className='col'>
                    <input type='text' id='mobile' name='mobile' className='form-control' placeholder='Enter Mobile' onChange={this.changeHandler} defaultValue={mobile}></input>
                </div>
            </div>
            <div className='row mt-5'>
                <div className='col'>
                <input type='text' id='email' name='email' className='form-control' placeholder='Enter Email' onChange={this.changeHandler} defaultValue={email}></input>
                </div>
            </div>
            <div className='row mt-5'>
                <div className='col'>
                    <button className='btn btn-success'>Submit</button>
                </div>
            </div>
        </form>
       </div>
      </div>
    )
  }
}

export default Add