import axios from 'axios';
import React, { Component } from 'react'

export class Delete extends Component {
    
    componentDidMount(){
        const _id = window.location.pathname.split('/')[2]
        // console.log(_id);
        axios.delete('http://localhost:4100/posts/'+_id)
        .then(res=>{
            console.log(res)
            if(res.status >= 200)
            {
                alert('User record deleted successfully')
                window.location = '../'
            }
        })
    }
  render() {
    return (
      <div>Delete</div>
    )
  }
}

export default Delete