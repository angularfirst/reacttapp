import axios from 'axios'
import React, { Component } from 'react'
import { Link } from 'react-router-dom'

export class Home extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         users:[]
      }
    }

    componentDidMount(){
        axios.get('http://localhost:4100/posts')
        .then(res=>{
            console.log(res.data);
            this.setState({users:res.data})
            console.log('State Data: ',this.state.users)
        })
    }
  render() {
    const {users} = this.state;
    return (
        <div>
            <div className='container mt-5'>
                <Link to={'/Add'} className='btn btn-success'>Add user</Link>
            </div>
            <div className='container mt-5'>
                <table className='table table-responsive table-bordered table-hover'>
                    <thead className='bg-success text-white text-center'>
                        <tr>
                            <th>Id</th>
                            <th>Name</th>
                            <th>Mobile</th>
                            <th>Email</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            users.map((x,i)=>
                            <tr key={i}>
                                <td>{x.id}</td>
                                <td>{x.name}</td>
                                <td>{x.mobile}</td>
                                <td>{x.email}</td>
                                <td>
                                    <Link to={`/Edit/${x.id}`} className='btn btn-warning'>Edit</Link>
                                    <Link to={`/Delete/${x.id}`} className='btn btn-danger'>Delete</Link>
                                </td>
                            </tr>
                            )
                        }
                    </tbody>
                </table>
            </div>
        </div>
    )
  }
}

export default Home